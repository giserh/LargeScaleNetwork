package Classifier;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;

public class test {

	static public void main(String[] args){
		HashMap<String, Integer> m1 = new HashMap<String, Integer>();
		m1.put("d", 10);
		m1.put("b", 13);
		m1.put("r", 3);
		m1.put("t", 23);

		
	}
	
}
