package optimization.gradientBasedMethods;



public interface ProjectedOptimizer extends Optimizer{
	
	
	
	
}
