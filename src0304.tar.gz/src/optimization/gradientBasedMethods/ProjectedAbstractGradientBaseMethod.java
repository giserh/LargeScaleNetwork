package optimization.gradientBasedMethods;


/**
 * 
 * @author javg
 *
 */
public abstract class ProjectedAbstractGradientBaseMethod extends AbstractGradientBaseMethod implements ProjectedOptimizer{
	
}
