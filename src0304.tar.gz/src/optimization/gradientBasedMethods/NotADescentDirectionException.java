package optimization.gradientBasedMethods;

public class NotADescentDirectionException extends RuntimeException {

	public NotADescentDirectionException(String str){
		super(str);
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
